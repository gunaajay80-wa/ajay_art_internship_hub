</main>
<footer class="footer">&copy; <?= date('Y') ?> College Internship Application Portal</footer>
<script src="<?= app_url('js/validation.js') ?>"></script>
</body>
</html>
