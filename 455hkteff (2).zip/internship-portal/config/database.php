<?php
// Local database for Nimbus: JSON files, no MySQL server required.
// ByteXL/Nimbus proxies the application under /proxy/8001/ (or another port).
// The proxy may strip that prefix before PHP sees the request, so root-relative
// URLs such as /login.php can escape the proxy and return "Not found".
// Use paths relative to the current PHP page instead.
define('BASE_URL', '');

function app_url(string $path): string {
    $path = ltrim($path, '/');
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $dir = trim(dirname($script), '/.');
    $depth = $dir === '' ? 0 : count(array_filter(explode('/', $dir)));
    return str_repeat('../', $depth) . $path;
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

class JsonDB {
    private string $dir;

    public function __construct(string $dir) {
        $this->dir = $dir;
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
    }

    private function path(string $table): string {
        return $this->dir . '/' . $table . '.json';
    }

    private function load(string $table): array {
        $file = $this->path($table);
        if (!file_exists($file)) {
            file_put_contents($file, "[]", LOCK_EX);
        }
        $data = json_decode((string)file_get_contents($file), true);
        return is_array($data) ? $data : [];
    }

    private function save(string $table, array $rows): void {
        file_put_contents(
            $this->path($table),
            json_encode($rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );
    }

    public function all(string $table): array {
        return $this->load($table);
    }

    public function find(string $table, int $id): ?array {
        foreach ($this->load($table) as $row) {
            if ((int)($row['id'] ?? 0) === $id) return $row;
        }
        return null;
    }

    public function first(string $table, callable $filter): ?array {
        foreach ($this->load($table) as $row) {
            if ($filter($row)) return $row;
        }
        return null;
    }

    public function where(string $table, callable $filter): array {
        return array_values(array_filter($this->load($table), $filter));
    }

    public function insert(string $table, array $row): int {
        $rows = $this->load($table);
        $max = 0;
        foreach ($rows as $r) $max = max($max, (int)($r['id'] ?? 0));
        $row['id'] = $max + 1;
        $now = date('Y-m-d H:i:s');
        if (in_array($table, ['users','internships'], true) && !isset($row['created_at'])) {
            $row['created_at'] = $now;
        }
        if ($table === 'applications' && !isset($row['applied_at'])) {
            $row['applied_at'] = $now;
        }
        $rows[] = $row;
        $this->save($table, $rows);
        return (int)$row['id'];
    }

    public function update(string $table, int $id, array $changes): bool {
        $rows = $this->load($table);
        $changed = false;
        foreach ($rows as &$row) {
            if ((int)($row['id'] ?? 0) === $id) {
                $row = array_merge($row, $changes);
                $changed = true;
                break;
            }
        }
        unset($row);
        if ($changed) $this->save($table, $rows);
        return $changed;
    }

    public function updateWhere(string $table, callable $filter, array $changes): int {
        $rows = $this->load($table);
        $count = 0;
        foreach ($rows as &$row) {
            if ($filter($row)) {
                $row = array_merge($row, $changes);
                $count++;
            }
        }
        unset($row);
        if ($count) $this->save($table, $rows);
        return $count;
    }

    public function deleteWhere(string $table, callable $filter): int {
        $rows = $this->load($table);
        $kept = [];
        $count = 0;
        foreach ($rows as $row) {
            if ($filter($row)) $count++;
            else $kept[] = $row;
        }
        if ($count) $this->save($table, $kept);
        return $count;
    }
}

$persistentDataDir = dirname(__DIR__, 2) . '/internship-data';
$pdo = new JsonDB($persistentDataDir);
?>
