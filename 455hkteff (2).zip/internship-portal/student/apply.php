<?php
require_once __DIR__.'/../includes/functions.php'; require_role('student');
$student=get_student($pdo); $id=(int)($_GET['id']??$_POST['id']??0); $i=internship_by_id($pdo,$id);
if(!$i || ($i['status']??'')!=='Open' || (($i['deadline']??'')!=='' && $i['deadline']<date('Y-m-d'))){ flash('This internship is not available.','error'); redirect('student/internships.php'); }
if(application_exists($pdo,$id,$student['id'])){ flash('You have already applied for this internship.','info'); redirect('student/applications.php'); }
if($_SERVER['REQUEST_METHOD']==='POST'){
    $pdo->insert('applications',['internship_id'=>$id,'student_id'=>$student['id'],'cover_letter'=>trim($_POST['cover_letter']??''),'status'=>'Applied']);
    flash('Application submitted successfully!'); redirect('student/applications.php');
}
$c=company_by_id($pdo,$i['company_id']); $pageTitle='Apply'; include __DIR__.'/../includes/header.php';
?>
<h2>Apply for: <?=e($i['title'])?></h2><div class="card"><p class="muted"><?=e($c['company_name']??'')?> &middot; <?=e($i['location']??'')?></p><p><?=nl2br(e($i['description']))?></p><div><?=skill_chips($i['skills_required']??'')?></div></div>
<?php if(empty($student['resume'])): ?><div class="alert info">You have not uploaded a resume yet. <a href="profile.php">Upload it in your profile</a>.</div><?php endif; ?>
<form method="post" class="form-wide"><input type="hidden" name="id" value="<?=$id?>"><label>Cover letter (optional)</label><textarea name="cover_letter" rows="6"></textarea><button class="btn">Submit Application</button><a href="internships.php" class="btn btn-outline">Cancel</a></form>
<?php include __DIR__.'/../includes/footer.php'; ?>
