<?php
require_once __DIR__ . '/includes/functions.php';
$all=$pdo->where('internships', function($i){
    return ($i['status']??'Open')==='Open' &&
        (($i['deadline']??'')==='' || $i['deadline']>=date('Y-m-d'));
});
usort($all, fn($a,$b)=>strcmp($b['created_at']??'', $a['created_at']??''));
$latest=array_slice($all,0,6);
$pageTitle='Home'; include __DIR__.'/includes/header.php';
?>
<section class="hero">
    <div class="hero-copy">
        <span class="hero-kicker">Campus to career &nbsp;•&nbsp; One portal</span>
        <h1>Build experience that moves your career forward.</h1>
        <p>Discover relevant internships, apply in minutes, and track every opportunity from one focused workspace.</p>
        <div class="hero-actions">
            <?php if(is_logged_in()): ?><a class="btn" href="<?=app_url(dashboard_path())?>">Go to Dashboard &nbsp;→</a>
            <?php else: ?><a class="btn" href="<?=app_url('register.php')?>">Start exploring &nbsp;→</a>
            <a class="btn btn-outline" href="<?=app_url('login.php')?>">Sign in</a><?php endif; ?>
        </div>
    </div>
    <aside class="hero-panel" aria-label="Portal highlights">
        <span class="mini-label">YOUR CAREER LAUNCHPAD</span>
        <strong>Find the right fit.</strong>
        <div class="mini-row"><span class="dot"></span> Discover roles matched to your skills</div>
        <div class="mini-row"><span class="dot"></span> Apply without leaving the portal</div>
        <div class="mini-row"><span class="dot"></span> Follow your application status</div>
    </aside>
</section>
<h2>Latest internships</h2>
<?php if(!$latest): ?><p class="muted">No internships posted yet.</p>
<?php else: ?><div class="grid">
<?php foreach($latest as $i): $c=company_by_id($pdo,$i['company_id']); ?>
<div class="card"><h3><?=e($i['title'])?></h3>
<p class="muted"><?=e($c['company_name']??'')?> &middot; <?=e($i['location']??'')?></p>
<p><?=e(mb_strimwidth($i['description'],0,110,'...'))?></p>
<div><?=skill_chips($i['skills_required']??'')?></div></div>
<?php endforeach; ?></div><?php endif; ?>
<?php include __DIR__.'/includes/footer.php'; ?>
