document.addEventListener('DOMContentLoaded', function () {

    function showError(input, message) {
        input.classList.add('invalid');
        var msg = document.createElement('div');
        msg.className = 'field-error';
        msg.textContent = message;
        input.parentNode.insertBefore(msg, input.nextSibling);
    }

    function clearErrors(form) {
        form.querySelectorAll('.field-error').forEach(function (el) { el.remove(); });
        form.querySelectorAll('.invalid').forEach(function (el) { el.classList.remove('invalid'); });
    }

    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Login form
    var loginForm = document.querySelector('form[data-validate="login"]');
    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            clearErrors(loginForm);
            var ok = true;
            if (!emailPattern.test(loginForm.email.value.trim())) {
                showError(loginForm.email, 'Enter a valid email address.');
                ok = false;
            }
            if (loginForm.password.value === '') {
                showError(loginForm.password, 'Password is required.');
                ok = false;
            }
            if (!ok) { e.preventDefault(); }
        });
    }

    // Register form
    var regForm = document.querySelector('form[data-validate="register"]');
    if (regForm) {
        var roleSelect = regForm.querySelector('#role');
        var companyField = document.getElementById('company-field');

        function toggleCompany() {
            if (companyField && roleSelect) {
                companyField.style.display = roleSelect.value === 'company' ? 'block' : 'none';
            }
        }
        if (roleSelect) {
            roleSelect.addEventListener('change', toggleCompany);
            toggleCompany();
        }

        regForm.addEventListener('submit', function (e) {
            clearErrors(regForm);
            var ok = true;
            if (regForm.name.value.trim() === '') {
                showError(regForm.name, 'Name is required.');
                ok = false;
            }
            if (roleSelect && roleSelect.value === 'company' && regForm.company_name.value.trim() === '') {
                showError(regForm.company_name, 'Company name is required.');
                ok = false;
            }
            if (!emailPattern.test(regForm.email.value.trim())) {
                showError(regForm.email, 'Enter a valid email address.');
                ok = false;
            }
            if (regForm.password.value.length < 6) {
                showError(regForm.password, 'Password must be at least 6 characters.');
                ok = false;
            }
            if (regForm.password.value !== regForm.confirm_password.value) {
                showError(regForm.confirm_password, 'Passwords do not match.');
                ok = false;
            }
            if (!ok) { e.preventDefault(); }
        });
    }

    // Button ripple animation. This is visual only and never changes navigation.
    document.querySelectorAll('.btn, .btn-nav').forEach(function (button) {
        button.addEventListener('click', function (event) {
            var rect = button.getBoundingClientRect();
            var ripple = document.createElement('span');
            var size = Math.max(rect.width, rect.height) * 1.25;
            ripple.className = 'ripple';
            ripple.style.width = size + 'px';
            ripple.style.height = size + 'px';
            ripple.style.left = (event.clientX - rect.left - size / 2) + 'px';
            ripple.style.top = (event.clientY - rect.top - size / 2) + 'px';
            button.appendChild(ripple);
            setTimeout(function () { ripple.remove(); }, 650);
        });
    });

    // Smooth reveal for cards, stats and panels.
    var revealItems = document.querySelectorAll('.card, .stat, .form-box, .form-wide, .search-bar, table');
    revealItems.forEach(function (el, index) {
        el.classList.add('reveal');
        el.style.transitionDelay = Math.min(index * 45, 240) + 'ms';
    });

    if ('IntersectionObserver' in window) {
        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.08 });
        revealItems.forEach(function (el) { observer.observe(el); });
    } else {
        revealItems.forEach(function (el) { el.classList.add('revealed'); });
    }

    // Add a small loading state only after a valid form submission.
    document.querySelectorAll('form').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (event.defaultPrevented) return;
            var submit = form.querySelector('button[type="submit"], input[type="submit"]');
            if (submit && !submit.classList.contains('loading')) {
                submit.classList.add('loading');
                submit.setAttribute('aria-busy', 'true');
            }
        });
    });
});
