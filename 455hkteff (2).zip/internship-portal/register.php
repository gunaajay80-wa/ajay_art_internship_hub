<?php
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) redirect(dashboard_path());

$errors = [];
$old = ['name'=>'','email'=>'','role'=>'student','company_name'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['name'] = trim($_POST['name'] ?? '');
    $old['email'] = trim($_POST['email'] ?? '');
    $old['role'] = $_POST['role'] ?? 'student';
    $old['company_name'] = trim($_POST['company_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($old['name'] === '') $errors[] = 'Name is required.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!in_array($old['role'], ['student','company'], true)) $errors[] = 'Select a valid role.';
    if ($old['role'] === 'company' && $old['company_name'] === '') $errors[] = 'Company name is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (!$errors && $pdo->first('users', fn($u) => strtolower($u['email']) === strtolower($old['email']))) {
        $errors[] = 'This email is already registered.';
    }

    if (!$errors) {
        $uid = $pdo->insert('users', [
            'name'=>$old['name'],
            'email'=>$old['email'],
            'password'=>password_hash($password, PASSWORD_DEFAULT),
            'role'=>$old['role']
        ]);
        if ($old['role'] === 'student') {
            $pdo->insert('students', [
                'user_id'=>$uid,'phone'=>'','college'=>'','course'=>'',
                'year_of_study'=>'','skills'=>'','about'=>'','resume'=>''
            ]);
        } else {
            $pdo->insert('companies', [
                'user_id'=>$uid,'company_name'=>$old['company_name'],
                'website'=>'','location'=>'','description'=>''
            ]);
        }
        flash('Registration successful! Please login.');
        redirect('login.php');
    }
}

$pageTitle='Register';
include __DIR__ . '/includes/header.php';
?>
<div class="form-box">
<h2>Create an account</h2>
<?php foreach ($errors as $err): ?><div class="alert error"><?=e($err)?></div><?php endforeach; ?>
<form method="post" data-validate="register" novalidate>
<label>Register as</label>
<select name="role" id="role">
<option value="student" <?=$old['role']==='student'?'selected':''?>>Student</option>
<option value="company" <?=$old['role']==='company'?'selected':''?>>Company</option>
</select>
<label>Full Name</label>
<input type="text" name="name" value="<?=e($old['name'])?>">
<div id="company-field" style="<?=$old['role']==='company'?'':'display:none'?>">
<label>Company Name</label>
<input type="text" name="company_name" value="<?=e($old['company_name'])?>">
</div>
<label>Email</label><input type="email" name="email" value="<?=e($old['email'])?>">
<label>Password</label><input type="password" name="password">
<label>Confirm Password</label><input type="password" name="confirm_password">
<button type="submit" class="btn">Register</button>
</form>
<p class="muted">Already have an account? <a href="login.php">Login</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
