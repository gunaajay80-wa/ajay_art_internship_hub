<?php
require_once __DIR__.'/../includes/functions.php'; require_role('student');
$student=get_student($pdo); $apps=$pdo->where('applications',fn($a)=>(int)$a['student_id']===(int)$student['id']); usort($apps,fn($a,$b)=>strcmp($b['applied_at']??'',$a['applied_at']??''));
$stages=['Applied','Under Review','Shortlisted','Interview','Selected']; $pageTitle='My Applications'; include __DIR__.'/../includes/header.php';
?>
<h2>My Applications</h2>
<?php if(!$apps): ?><p class="muted">No applications yet. <a href="internships.php">Browse internships</a>.</p>
<?php else: foreach($apps as $a): $i=internship_by_id($pdo,$a['internship_id']); $c=company_by_id($pdo,$i['company_id']??0); $current=array_search($a['status'],$stages,true); ?>
<div class="card app-card"><div class="app-head"><div><h3><?=e($i['title']??'')?></h3><p class="muted"><?=e($c['company_name']??'')?> &middot; <?=e($i['location']??'')?> &middot; Applied on <?=e(date('d M Y',strtotime($a['applied_at'])))?></p></div><span class="<?=status_class($a['status'])?>"><?=e($a['status'])?></span></div>
<?php if($a['status']==='Rejected'): ?><p class="muted">Unfortunately, your application was not selected this time.</p>
<?php else: ?><ol class="tracker"><?php foreach($stages as $idx=>$stage): ?><li class="<?=$idx<$current?'done':($idx===$current?'current':'')?>"><?=e($stage)?></li><?php endforeach; ?></ol><?php endif; ?></div>
<?php endforeach; endif; ?>
<?php include __DIR__.'/../includes/footer.php'; ?>
