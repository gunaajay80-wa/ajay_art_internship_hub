<?php
require_once __DIR__ . '/../config/database.php';

const APP_STATUSES = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected'];

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header('Location: ' . app_url($path));
    exit;
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function dashboard_path() {
    return (isset($_SESSION['role']) && $_SESSION['role'] === 'company')
        ? 'company/dashboard.php'
        : 'student/dashboard.php';
}

function require_role($role) {
    if (!is_logged_in()) redirect('login.php');
    if ($_SESSION['role'] !== $role) redirect(dashboard_path());
}

function flash($message, $type = 'success') {
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}

function show_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        echo '<div class="alert ' . e($f['type']) . '">' . e($f['message']) . '</div>';
    }
}

function get_student($db) {
    return $db->first('students', fn($r) => (int)$r['user_id'] === (int)$_SESSION['user_id']);
}

function get_company($db) {
    return $db->first('companies', fn($r) => (int)$r['user_id'] === (int)$_SESSION['user_id']);
}

function status_class($status) {
    return 'badge badge-' . strtolower(str_replace(' ', '-', $status));
}

function skill_chips($skills) {
    $out = '';
    foreach (explode(',', (string)$skills) as $s) {
        $s = trim($s);
        if ($s !== '') $out .= '<span class="chip">' . e($s) . '</span>';
    }
    return $out;
}

function company_by_id($db, $id) {
    return $db->find('companies', (int)$id);
}

function user_by_id($db, $id) {
    return $db->find('users', (int)$id);
}

function internship_by_id($db, $id) {
    return $db->find('internships', (int)$id);
}

function application_exists($db, $internshipId, $studentId) {
    return $db->first('applications', fn($a) =>
        (int)$a['internship_id'] === (int)$internshipId &&
        (int)$a['student_id'] === (int)$studentId
    );
}
?>
