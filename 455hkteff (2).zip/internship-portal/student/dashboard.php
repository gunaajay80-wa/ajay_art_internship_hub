<?php
require_once __DIR__.'/../includes/functions.php'; require_role('student');
$student=get_student($pdo); $apps=$pdo->where('applications',fn($a)=>(int)$a['student_id']===(int)$student['id']);
$counts=[]; foreach($apps as $a) $counts[$a['status']]=($counts[$a['status']]??0)+1;
usort($apps,fn($a,$b)=>strcmp($b['applied_at']??'', $a['applied_at']??'')); $recent=array_slice($apps,0,5);
$profileIncomplete=empty($student['college'])||empty($student['skills'])||empty($student['resume']);
$pageTitle='Student Dashboard'; include __DIR__.'/../includes/header.php';
?>
<h2>Welcome, <?=e($_SESSION['name'])?></h2>
<?php if($profileIncomplete): ?><div class="alert info">Your profile is incomplete. <a href="profile.php">Complete your profile</a>.</div><?php endif; ?>
<div class="stats">
<div class="stat"><span><?=array_sum($counts)?></span>Total Applications</div>
<div class="stat"><span><?=$counts['Shortlisted']??0?></span>Shortlisted</div>
<div class="stat"><span><?=$counts['Interview']??0?></span>Interview</div>
<div class="stat"><span><?=$counts['Selected']??0?></span>Selected</div>
</div>
<h3>Recent Applications</h3>
<?php if(!$recent): ?><p class="muted">You haven't applied yet. <a href="internships.php">Browse internships</a>.</p>
<?php else: ?><table><tr><th>Internship</th><th>Company</th><th>Applied On</th><th>Status</th></tr>
<?php foreach($recent as $a): $i=internship_by_id($pdo,$a['internship_id']); $c=company_by_id($pdo,$i['company_id']??0); ?>
<tr><td><?=e($i['title']??'')?></td><td><?=e($c['company_name']??'')?></td><td><?=e(date('d M Y',strtotime($a['applied_at'])))?></td><td><span class="<?=status_class($a['status'])?>"><?=e($a['status'])?></span></td></tr>
<?php endforeach; ?></table><?php endif; ?>
<?php include __DIR__.'/../includes/footer.php'; ?>
