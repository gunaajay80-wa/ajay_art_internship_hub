<?php
require_once __DIR__.'/../includes/functions.php'; require_role('company'); $company=get_company($pdo); $internshipId=(int)($_GET['internship_id']??$_POST['internship_id']??0);
$myInternships=$pdo->where('internships',fn($i)=>(int)$i['company_id']===(int)$company['id']);
if($_SERVER['REQUEST_METHOD']==='POST'){ $appId=(int)($_POST['application_id']??0);$status=$_POST['status']??'';$a=$pdo->find('applications',$appId);$i=$a?internship_by_id($pdo,$a['internship_id']):null;
if($a&&$i&&(int)$i['company_id']===(int)$company['id']&&in_array($status,APP_STATUSES,true)){$pdo->update('applications',$appId,['status'=>$status]);flash('Application marked as '.$status.'.');}else flash('Invalid application or status.','error');
redirect('company/applicants.php'.($internshipId?'?internship_id='.$internshipId:''));}
$applicants=[];
foreach($myInternships as $i){if($internshipId&&(int)$i['id']!==$internshipId)continue;foreach($pdo->where('applications',fn($a)=>(int)$a['internship_id']===(int)$i['id']) as $a){$s=$pdo->find('students',$a['student_id']);$u=$s?$pdo->find('users',$s['user_id']):null;$a['title']=$i['title'];$a['student']=$s;$a['user']=$u;$applicants[]=$a;}}
usort($applicants,fn($a,$b)=>strcmp($b['applied_at']??'',$a['applied_at']??''));
$pageTitle='Applicants';include __DIR__.'/../includes/header.php';
?>
<h2>Applicants</h2><form method="get" class="search-bar"><select name="internship_id"><option value="0">All internships</option><?php foreach($myInternships as $m):?><option value="<?=$m['id']?>" <?=$internshipId===$m['id']?'selected':''?>><?=e($m['title'])?></option><?php endforeach;?></select><button class="btn">Filter</button></form>
<?php if(!$applicants):?><p class="muted">No applicants found.</p><?php else:foreach($applicants as $a):$s=$a['student']??[];$u=$a['user']??[];?>
<div class="card app-card"><div class="app-head"><div><h3><?=e($u['name']??'')?></h3><p class="muted">Applied for <strong><?=e($a['title'])?></strong> on <?=e(date('d M Y',strtotime($a['applied_at'])))?></p></div><span class="<?=status_class($a['status'])?>"><?=e($a['status'])?></span></div>
<p class="small">Email: <?=e($u['email']??'-')?> | Phone: <?=e($s['phone']??'-')?><br>College: <?=e($s['college']??'-')?> | Course: <?=e($s['course']??'-')?> | <?=e($s['year_of_study']??'-')?></p><div><?=skill_chips($s['skills']??'')?></div>
<?php if(!empty($a['cover_letter'])):?><p><strong>Cover letter:</strong> <?=nl2br(e($a['cover_letter']))?></p><?php endif;?>
<?php if(!empty($s['resume'])):?><p><a target="_blank" href="<?=app_url('uploads/resumes/')?><?=e($s['resume'])?>">View Resume</a></p><?php else:?><p class="muted">No resume uploaded.</p><?php endif;?>
<div class="actions"><form method="post"><input type="hidden" name="application_id" value="<?=$a['id']?>"><input type="hidden" name="internship_id" value="<?=$internshipId?>"><select name="status"><?php foreach(APP_STATUSES as $st):?><option value="<?=e($st)?>" <?=$a['status']===$st?'selected':''?>><?=e($st)?></option><?php endforeach;?></select><button class="btn btn-small">Update</button></form><form method="post"><input type="hidden" name="application_id" value="<?=$a['id']?>"><input type="hidden" name="internship_id" value="<?=$internshipId?>"><input type="hidden" name="status" value="Shortlisted"><button class="btn btn-small btn-success">Shortlist</button></form><form method="post"><input type="hidden" name="application_id" value="<?=$a['id']?>"><input type="hidden" name="internship_id" value="<?=$internshipId?>"><input type="hidden" name="status" value="Rejected"><button class="btn btn-small btn-danger">Reject</button></form></div></div>
<?php endforeach;endif;?>
<?php include __DIR__.'/../includes/footer.php'; ?>
