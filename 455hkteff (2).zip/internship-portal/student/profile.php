<?php
require_once __DIR__.'/../includes/functions.php'; require_role('student');
$student=get_student($pdo); $errors=[];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $phone=trim($_POST['phone']??''); $college=trim($_POST['college']??''); $course=trim($_POST['course']??''); $year=trim($_POST['year_of_study']??''); $about=trim($_POST['about']??'');
    $skillList=array_filter(array_map('trim',explode(',',$_POST['skills']??'')),'strlen'); $skills=implode(', ',array_unique($skillList)); $resumeName=$student['resume']??'';
    if($phone!==''&&!preg_match('/^[0-9+\-\s]{7,15}$/',$phone)) $errors[]='Enter a valid phone number.';
    if(isset($_FILES['resume'])&&$_FILES['resume']['error']!==UPLOAD_ERR_NO_FILE){
        if($_FILES['resume']['error']!==UPLOAD_ERR_OK) $errors[]='Resume upload failed.';
        else{$ext=strtolower(pathinfo($_FILES['resume']['name'],PATHINFO_EXTENSION));
            if(!in_array($ext,['pdf','doc','docx'],true)) $errors[]='Resume must be PDF, DOC or DOCX.';
            elseif($_FILES['resume']['size']>2*1024*1024)$errors[]='Resume must be smaller than 2 MB.';
            else{$dir=__DIR__.'/../uploads/resumes/'; if(!is_dir($dir))mkdir($dir,0777,true); $new='resume_'.$student['id'].'_'.time().'.'.$ext;
                if(move_uploaded_file($_FILES['resume']['tmp_name'],$dir.$new)){if(!empty($resumeName)&&is_file($dir.$resumeName))unlink($dir.$resumeName);$resumeName=$new;}else $errors[]='Could not save resume.';}
        }
    }
    if(!$errors){$pdo->update('students',$student['id'],['phone'=>$phone,'college'=>$college,'course'=>$course,'year_of_study'=>$year,'skills'=>$skills,'about'=>$about,'resume'=>$resumeName]);flash('Profile updated successfully.');redirect('student/profile.php');}
    $student=array_merge($student,['phone'=>$phone,'college'=>$college,'course'=>$course,'year_of_study'=>$year,'skills'=>$skills,'about'=>$about,'resume'=>$resumeName]);
}
$pageTitle='My Profile'; include __DIR__.'/../includes/header.php';
?>
<h2>My Profile</h2><?php foreach($errors as $err): ?><div class="alert error"><?=e($err)?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data" class="form-wide">
<div class="row"><div><label>Phone</label><input name="phone" value="<?=e($student['phone'])?>"></div><div><label>College</label><input name="college" value="<?=e($student['college'])?>"></div></div>
<div class="row"><div><label>Course / Branch</label><input name="course" value="<?=e($student['course'])?>"></div><div><label>Year of Study</label><select name="year_of_study"><?php foreach(['','1st Year','2nd Year','3rd Year','4th Year'] as $y): ?><option value="<?=e($y)?>" <?=$student['year_of_study']===$y?'selected':''?>><?=$y===''?'Select':e($y)?></option><?php endforeach; ?></select></div></div>
<label>Skills (comma separated)</label><input name="skills" value="<?=e($student['skills'])?>" placeholder="PHP, MySQL, HTML, CSS"><div class="chips"><?=skill_chips($student['skills'])?></div>
<label>About me</label><textarea name="about" rows="4"><?=e($student['about'])?></textarea>
<label>Resume (PDF/DOC/DOCX, max 2 MB)</label><input type="file" name="resume" accept=".pdf,.doc,.docx">
<?php if(!empty($student['resume'])):?><p class="muted">Current resume: <a target="_blank" href="<?=app_url('uploads/resumes/')?><?=e($student['resume'])?>">View</a></p><?php endif;?>
<button class="btn">Save Profile</button></form>
<?php include __DIR__.'/../includes/footer.php'; ?>
