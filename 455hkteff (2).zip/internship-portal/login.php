<?php
require_once __DIR__ . '/includes/functions.php';
if (is_logged_in()) redirect(dashboard_path());

$error=''; $email='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=trim($_POST['email']??''); $password=$_POST['password']??'';
    if ($email==='' || $password==='') $error='Please enter email and password.';
    else {
        $user=$pdo->first('users', fn($u)=>strtolower($u['email'])===strtolower($email));
        if ($user && password_verify($password,$user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']=(int)$user['id'];
            $_SESSION['name']=$user['name'];
            $_SESSION['role']=$user['role'];
            redirect(dashboard_path());
        } else $error='Invalid email or password.';
    }
}
$pageTitle='Login'; include __DIR__.'/includes/header.php';
?>
<div class="form-box">
<h2>Login</h2>
<?php if($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?>
<form method="post" data-validate="login" novalidate>
<label>Email</label><input type="email" name="email" value="<?=e($email)?>">
<label>Password</label><input type="password" name="password">
<button type="submit" class="btn">Login</button>
</form>
<p class="muted">New here? <a href="register.php">Create an account</a></p>
</div>
<?php include __DIR__.'/includes/footer.php'; ?>
