<?php
require_once __DIR__ . '/functions.php';
$pageTitle = $pageTitle ?? 'Home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - Internship Portal</title>
    <style>
<?php readfile(__DIR__ . '/../css/style.css'); ?>
    </style>
</head>
<body>
<header class="navbar">
    <a class="brand" href="<?= app_url('index.php') ?>">InternPortal</a>
    <nav>
        <?php if (is_logged_in() && $_SESSION['role'] === 'student'): ?>
            <a href="<?= app_url('student/dashboard.php') ?>">Dashboard</a>
            <a href="<?= app_url('student/profile.php') ?>">Profile</a>
            <a href="<?= app_url('student/internships.php') ?>">Internships</a>
            <a href="<?= app_url('student/applications.php') ?>">My Applications</a>
            <a href="<?= app_url('logout.php') ?>" class="btn-nav">Logout (<?= e($_SESSION['name']) ?>)</a>
        <?php elseif (is_logged_in() && $_SESSION['role'] === 'company'): ?>
            <a href="<?= app_url('company/dashboard.php') ?>">Dashboard</a>
            <a href="<?= app_url('company/add_internship.php') ?>">Add Internship</a>
            <a href="<?= app_url('company/internships.php') ?>">My Internships</a>
            <a href="<?= app_url('company/applicants.php') ?>">Applicants</a>
            <a href="<?= app_url('logout.php') ?>" class="btn-nav">Logout (<?= e($_SESSION['name']) ?>)</a>
        <?php else: ?>
            <a href="<?= app_url('login.php') ?>">Login</a>
            <a href="<?= app_url('register.php') ?>" class="btn-nav">Register</a>
        <?php endif; ?>
    </nav>
</header>
<main class="container">
<?php show_flash(); ?>
