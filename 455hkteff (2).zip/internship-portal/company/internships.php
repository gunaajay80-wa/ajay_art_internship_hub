<?php
require_once __DIR__.'/../includes/functions.php'; require_role('company'); $company=get_company($pdo);
if($_SERVER['REQUEST_METHOD']==='POST'){ $id=(int)($_POST['id']??0); $action=$_POST['action']??'';
if($action==='toggle'){$i=$pdo->find('internships',$id);if($i&&(int)$i['company_id']===(int)$company['id'])$pdo->update('internships',$id,['status'=>$i['status']==='Open'?'Closed':'Open']);flash('Internship status updated.');}
elseif($action==='delete'){$pdo->deleteWhere('applications',fn($a)=>(int)$a['internship_id']===$id);$pdo->deleteWhere('internships',fn($i)=>(int)$i['id']===$id&&(int)$i['company_id']===(int)$company['id']);flash('Internship deleted.');}
redirect('company/internships.php');}
$internships=$pdo->where('internships',fn($i)=>(int)$i['company_id']===(int)$company['id']);usort($internships,fn($a,$b)=>strcmp($b['created_at']??'',$a['created_at']??''));
$pageTitle='My Internships';include __DIR__.'/../includes/header.php';
?>
<h2>My Internships</h2><p><a class="btn" href="add_internship.php">+ Add Internship</a></p>
<?php if(!$internships):?><p class="muted">You have not posted any internships yet.</p><?php else:?><table><tr><th>Title</th><th>Location</th><th>Deadline</th><th>Status</th><th>Applicants</th><th>Actions</th></tr>
<?php foreach($internships as $i):$n=count($pdo->where('applications',fn($a)=>(int)$a['internship_id']===(int)$i['id']));?><tr><td><?=e($i['title'])?></td><td><?=e($i['location']??'')?></td><td><?=$i['deadline']?e(date('d M Y',strtotime($i['deadline']))):'-'?></td><td><span class="badge"><?=$i['status']?></span></td><td><a href="applicants.php?internship_id=<?=$i['id']?>"><?=$n?></a></td><td class="actions"><form method="post"><input type="hidden" name="id" value="<?=$i['id']?>"><input type="hidden" name="action" value="toggle"><button class="btn btn-small btn-outline"><?=$i['status']==='Open'?'Close':'Reopen'?></button></form><form method="post" onsubmit="return confirm('Delete this internship and applications?')"><input type="hidden" name="id" value="<?=$i['id']?>"><input type="hidden" name="action" value="delete"><button class="btn btn-small btn-danger">Delete</button></form></td></tr><?php endforeach;?></table><?php endif;?>
<?php include __DIR__.'/../includes/footer.php'; ?>
