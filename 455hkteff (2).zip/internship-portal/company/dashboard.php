<?php
require_once __DIR__.'/../includes/functions.php'; require_role('company');
$company=get_company($pdo); $internships=$pdo->where('internships',fn($i)=>(int)$i['company_id']===(int)$company['id']);
$apps=[]; foreach($internships as $i) foreach($pdo->where('applications',fn($a)=>(int)$a['internship_id']===(int)$i['id']) as $a)$apps[]=$a;
$counts=[]; foreach($apps as $a)$counts[$a['status']]=($counts[$a['status']]??0)+1; usort($apps,fn($a,$b)=>strcmp($b['applied_at']??'',$a['applied_at']??'')); $recent=array_slice($apps,0,5);
$pageTitle='Company Dashboard'; include __DIR__.'/../includes/header.php';
?>
<h2>Welcome, <?=e($company['company_name'])?></h2><div class="stats"><div class="stat"><span><?=count($internships)?></span>Internships Posted</div><div class="stat"><span><?=count($apps)?></span>Total Applicants</div><div class="stat"><span><?=$counts['Shortlisted']??0?></span>Shortlisted</div><div class="stat"><span><?=$counts['Rejected']??0?></span>Rejected</div></div>
<p><a class="btn" href="add_internship.php">+ Add Internship</a> <a class="btn btn-outline" href="applicants.php">View Applicants</a></p>
<h3>Recent Applicants</h3>
<?php if(!$recent): ?><p class="muted">No applications received yet.</p><?php else:?><table><tr><th>Student</th><th>Internship</th><th>Applied On</th><th>Status</th></tr>
<?php foreach($recent as $a): $i=internship_by_id($pdo,$a['internship_id']); $s=$pdo->find('students',$a['student_id']); $u=user_by_id($pdo,$s['user_id']??0); ?><tr><td><?=e($u['name']??'')?></td><td><?=e($i['title']??'')?></td><td><?=e(date('d M Y',strtotime($a['applied_at'])))?></td><td><span class="<?=status_class($a['status'])?>"><?=e($a['status'])?></span></td></tr><?php endforeach;?></table><?php endif;?>
<?php include __DIR__.'/../includes/footer.php'; ?>
