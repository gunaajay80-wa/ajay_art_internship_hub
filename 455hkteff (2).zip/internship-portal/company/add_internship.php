<?php
require_once __DIR__.'/../includes/functions.php'; require_role('company'); $company=get_company($pdo); $errors=[];
$old=['title'=>'','description'=>'','skills_required'=>'','location'=>'','stipend'=>'','duration'=>'','deadline'=>''];
if($_SERVER['REQUEST_METHOD']==='POST'){foreach($old as $k=>$_)$old[$k]=trim($_POST[$k]??''); if($old['title']==='')$errors[]='Title is required.'; if($old['description']==='')$errors[]='Description is required.';
if($old['deadline']!==''){ $d=DateTime::createFromFormat('Y-m-d',$old['deadline']); if(!$d||$d->format('Y-m-d')!==$old['deadline'])$errors[]='Enter a valid deadline date.'; }
if(!$errors){$pdo->insert('internships',['company_id'=>$company['id'],'title'=>$old['title'],'description'=>$old['description'],'skills_required'=>$old['skills_required'],'location'=>$old['location'],'stipend'=>$old['stipend'],'duration'=>$old['duration'],'deadline'=>$old['deadline'],'status'=>'Open']);flash('Internship posted successfully.');redirect('company/internships.php');}}
$pageTitle='Add Internship';include __DIR__.'/../includes/header.php';
?>
<h2>Add Internship</h2><?php foreach($errors as $err):?><div class="alert error"><?=e($err)?></div><?php endforeach;?>
<form method="post" class="form-wide"><label>Title *</label><input name="title" value="<?=e($old['title'])?>"><label>Description *</label><textarea name="description" rows="5"><?=e($old['description'])?></textarea><label>Skills required</label><input name="skills_required" value="<?=e($old['skills_required'])?>" placeholder="PHP, MySQL, JavaScript"><div class="row"><div><label>Location</label><input name="location" value="<?=e($old['location'])?>"></div><div><label>Stipend</label><input name="stipend" value="<?=e($old['stipend'])?>"></div></div><div class="row"><div><label>Duration</label><input name="duration" value="<?=e($old['duration'])?>"></div><div><label>Application deadline</label><input type="date" name="deadline" value="<?=e($old['deadline'])?>"></div></div><button class="btn">Post Internship</button></form>
<?php include __DIR__.'/../includes/footer.php'; ?>
