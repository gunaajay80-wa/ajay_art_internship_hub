COLLEGE INTERNSHIP PORTAL - BYTE XL SAFE VERSION

IMPORTANT DATA SAFETY
----------------------
User accounts, company profiles, internships and applications are stored in:
  /home/workspace/my-project/internship-data/

This folder is intentionally OUTSIDE the internship-portal folder. Therefore, replacing or updating the UI ZIP will NOT delete your saved data.

START SERVER
------------
cd /home/workspace/my-project
php -S 0.0.0.0:8001 -t /home/workspace/my-project/internship-portal

Open the ByteXL forwarded port 8001 URL.

UPDATING THE UI
---------------
Do NOT run: rm -rf internship-portal if you want to preserve data unless you have already created the persistent data folder.
The current version uses internship-data outside the application folder, so normal UI replacement is safe.

MYSQL
-----
This version uses JSON storage and does not require a MySQL server.
