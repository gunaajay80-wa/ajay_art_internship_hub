<?php
require_once __DIR__.'/../includes/functions.php'; require_role('student');
$student=get_student($pdo); $q=trim($_GET['q']??''); $loc=trim($_GET['location']??'');
$internships=$pdo->where('internships',function($i)use($q,$loc){
    if(($i['status']??'Open')!=='Open') return false;
    if(($i['deadline']??'')!=='' && $i['deadline']<date('Y-m-d')) return false;
    $hay=strtolower(($i['title']??'').' '.($i['skills_required']??''));
    if($q!=='' && strpos($hay,strtolower($q))===false) return false;
    if($loc!=='' && strpos(strtolower($i['location']??''),strtolower($loc))===false) return false;
    return true;
});
foreach($internships as &$i){ $c=company_by_id($pdo,$i['company_id']); $i['company_name']=$c['company_name']??''; $i['applied']=application_exists($pdo,$i['id'],$student['id'])?1:0; }
unset($i); usort($internships,fn($a,$b)=>strcmp($b['created_at']??'',$a['created_at']??''));
$pageTitle='Search Internships'; include __DIR__.'/../includes/header.php';
?>
<h2>Search Internships</h2>
<form method="get" class="search-bar"><input type="text" name="q" placeholder="Title, skill or company" value="<?=e($q)?>"><input type="text" name="location" placeholder="Location" value="<?=e($loc)?>"><button class="btn">Search</button><a href="internships.php" class="btn btn-outline">Reset</a></form>
<p class="muted"><?=count($internships)?> internship(s) found</p>
<?php if(!$internships): ?><p class="muted">No internships match your search.</p>
<?php else: ?><div class="grid"><?php foreach($internships as $i): ?>
<div class="card"><h3><?=e($i['title'])?></h3><p class="muted"><?=e($i['company_name'])?> &middot; <?=e($i['location']??'')?></p><p><?=e(mb_strimwidth($i['description'],0,140,'...'))?></p><div><?=skill_chips($i['skills_required']??'')?></div><p class="small">Stipend: <?=e($i['stipend']?:'Not specified')?> | Duration: <?=e($i['duration']?:'Not specified')?><br>Deadline: <?=$i['deadline']?e(date('d M Y',strtotime($i['deadline']))):'Open'?></p>
<?php if($i['applied']): ?><span class="badge badge-applied">Already Applied</span><?php else: ?><a class="btn" href="apply.php?id=<?=(int)$i['id']?>">Apply Now</a><?php endif; ?></div>
<?php endforeach; ?></div><?php endif; ?>
<?php include __DIR__.'/../includes/footer.php'; ?>
